(function () {
  // pc opening
  lottie.loadAnimation({
    container: document.getElementById('jsi-kv'),
    renderer: 'svg',
    loop: false,
    autoplay: true,
    path: 'json/brwh_pc.json'
  });

  // about hackathone
  lottie.loadAnimation({
    container: document.getElementById('jsi-heading-about-pc'),
    renderer: 'svg',
    loop: true,
    autoplay: true,
    path: 'json/h-about.json'
  });

  // prize & incentive
  lottie.loadAnimation({
    container: document.getElementById('jsi-heading-prize-pc'),
    renderer: 'svg',
    loop: true,
    autoplay: true,
    path: 'json/h-prize-incentive.json'
  });

  // schedule
  lottie.loadAnimation({
    container: document.getElementById('jsi-heading-schedule-pc'),
    renderer: 'svg',
    loop: true,
    autoplay: true,
    path: 'json/h-schedule.json'
  });

  // process
  lottie.loadAnimation({
    container: document.getElementById('jsi-heading-process-pc'),
    renderer: 'svg',
    loop: true,
    autoplay: true,
    path: 'json/h-process.json'
  });
}());




// ScrollMagic
(function () {
	  var controller = new ScrollMagic.Controller();

    new ScrollMagic.Scene({triggerElement: '.jsc-scroll-150', triggerHook: 'onEnter', offset: 150})
	      .setClassToggle('.jsc-scroll-150', 'is-active')
	      .reverse(false)
	      .addTo(controller);

    new ScrollMagic.Scene({triggerElement: '.jsc-scroll-200', triggerHook: 'onEnter', offset: 200})
	      .setClassToggle('.jsc-scroll-200', 'is-active')
	      .reverse(false)
	      .addTo(controller);

    new ScrollMagic.Scene({triggerElement: '#jsi-scroll-schedule', triggerHook: 'onEnter', offset: 300})
	      .setClassToggle('#jsi-scroll-schedule', 'is-active')
	      .reverse(false)
	      .addTo(controller);

	  new ScrollMagic.Scene({triggerElement: '#jsi-header-scroll-trigger01', triggerHook: 'onEnter', offset: 150})
	      .setClassToggle('#jsi-header-scroll-trigger01', 'is-active')
	      .reverse(false)
	      .addTo(controller);

    new ScrollMagic.Scene({triggerElement: '#jsi-header-scroll-trigger02', triggerHook: 'onEnter', offset: 200})
	      .setClassToggle('#jsi-header-scroll-trigger02', 'is-active')
	      .reverse(false)
	      .addTo(controller);

    new ScrollMagic.Scene({triggerElement: '#jsi-header-scroll-trigger03', triggerHook: 'onEnter', offset: 300})
	      .setClassToggle('#jsi-header-scroll-trigger03', 'is-active')
	      .reverse(false)
	      .addTo(controller);

    new ScrollMagic.Scene({triggerElement: '#jsi-header-scroll-trigger04', triggerHook: 'onEnter', offset: 400})
	      .setClassToggle('#jsi-header-scroll-trigger04', 'is-active')
	      .reverse(false)
	      .addTo(controller);

    new ScrollMagic.Scene({triggerElement: '#jsi-entry-button', triggerHook: 'onEnter', offset: 400})
        .setClassToggle('#jsi-entry-button', 'is-active')
        .reverse(false)
        .addTo(controller);

    new ScrollMagic.Scene({triggerElement: '#jsi-requirements', triggerHook: 'onEnter', offset: 100})
        .setClassToggle('#jsi-requirements', 'is-active')
        .reverse(false)
        .addTo(controller);

    new ScrollMagic.Scene({triggerElement: '#jsi-about-bizreach', triggerHook: 'onEnter', offset: 0})
        .setClassToggle('#jsi-about-bizreach', 'is-active')
        .reverse(false)
        .addTo(controller);
}());


// opening animation
$(function() {
  setTimeout(function() {
      $('.c-kv-opening__01').fadeOut();
  	}, 4000);
});
$(function() {
  setTimeout(function() {
      $('.c-kv-opening__02').fadeOut();
  	}, 7000);
});
$(function() {
  setTimeout(function() {
      $('.c-kv-opening__03').addClass('active');
  	}, 4000);
});
$(function() {
  setTimeout(function() {
      $('.c-kv-opening__03--sp').addClass('active');
  	}, 10000);
});

// countdown
$("#jsi-countdown-days")
  .countdown("2019/09/25", function(event) {
    $(this).text(
      event.strftime('%D')
    );
});
$("#jsi-countdown-hours")
  .countdown("2019/09/25", function(event) {
    $(this).text(
      event.strftime('%H')
    );
});
$("#jsi-countdown-minutes")
  .countdown("2019/09/25", function(event) {
    $(this).text(
      event.strftime('%M')
    );
});

// sns
(function() {
    var shareButton = document.getElementsByClassName("share");
    for (var i = 0; i < shareButton.length; i++) {
        shareButton[i].addEventListener("click", function(e) {
            e.preventDefault();
            window.open(this.href, "SNS_window", "width=600, height=300, menubar=no, toolbar=no, scrollbars=yes");
        }, false);
    }
})()

// 動画
function popupImage() {
  var popup = document.getElementById('jsi-popup');
  if(!popup) return;

  var blackBg = document.getElementById('jsi-black-bg');
  var closeBtn = document.getElementById('jsi-close-btn');
  var showBtn = document.getElementById('jsi-show-popup');

  closePopUp(blackBg);
  closePopUp(closeBtn);
  closePopUp(showBtn);
  function closePopUp(elem) {
    if(!elem) return;
    elem.addEventListener('click', function() {
      popup.classList.toggle('is-show');
    });
  }
}
popupImage();
